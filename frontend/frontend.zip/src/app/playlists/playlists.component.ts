import { Component, OnInit } from "@angular/core";
import { PlaylistsService } from "../playlists.service";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import Swal from "sweetalert2";
import { RouterModule } from "@angular/router";
@Component({
  selector: "app-playlists",
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: "./playlists.component.html",
  styleUrl: "./playlists.component.scss",
})
export class PlaylistsComponent implements OnInit {
  myPlaylists: any[] = [];
  allPlaylists: any[] = [];
  showAll = false;
  loading = false;
  error = "";
  showAddSongsModal = false;
  selectedPlaylistForSongs: any = null;
  songIdsInput = "";
  addSongsError = "";
  addSongsSuccess = "";
  showCreateModal = false;
  showEditModal = false;
  showDeleteModal = false;
  selectedPlaylist: any = null;

  allSongs: any[] = [];
  selectedSongIds: Set<number> = new Set();

  newPlaylist = {
    playlistName: "",
    playlistDescription: "",
    playlistPicture: "",
  };

  constructor(private playlistsService: PlaylistsService) {}

  ngOnInit(): void {
    this.loadMyPlaylists();
  }

  loadMyPlaylists() {
    this.loading = true;
    this.error = "";
    this.playlistsService.getMyPlaylists().subscribe({
      next: (data: any) => {
        this.myPlaylists = data;
        this.loading = false;
      },
      error: (err: any) => {
        this.error = "Could not load your playlists.";
        this.loading = false;
      },
    });
  }

  loadAllPlaylists() {
    this.loading = true;
    this.error = "";
    this.playlistsService.getAllPlaylists().subscribe({
      next: (data) => {
        this.allPlaylists = data;
        this.showAll = true;
        this.loading = false;
      },
      error: (err: any) => {
        this.error = "Could not load all playlists.";
        this.loading = false;
      },
    });
  }

  hideAllPlaylists() {
    this.showAll = false;
    this.allPlaylists = [];
  }

  // CREATE
  openCreateModal() {
    this.newPlaylist = {
      playlistName: "",
      playlistDescription: "",
      playlistPicture: "",
    };
    this.showCreateModal = true;
  }
  createPlaylist() {
    this.playlistsService.createPlaylist(this.newPlaylist).subscribe({
      next: () => {
        this.showCreateModal = false;
        this.loadMyPlaylists();
        Swal.fire("Created!", "Playlist created.", "success");
      },
      error: () => {
        Swal.fire("Error", "Could not create playlist.", "error");
      },
    });
  }

  // EDIT
  openEditModal(playlist: any) {
    this.selectedPlaylist = { ...playlist };
    this.showEditModal = true;
  }
  updatePlaylist() {
    this.playlistsService
      .updatePlaylist(this.selectedPlaylist.playlistID, this.selectedPlaylist)
      .subscribe({
        next: () => {
          this.showEditModal = false;
          this.loadMyPlaylists();
          Swal.fire("Saved!", "Playlist updated.", "success");
        },
        error: () => {
          Swal.fire("Error", "Could not update playlist.", "error");
        },
      });
  }

  // DELETE
  openDeleteModal(playlist: any) {
    this.selectedPlaylist = playlist;
    this.showDeleteModal = true;
  }
  deletePlaylist() {
    Swal.fire({
      title: "Are you sure?",
      text: `Delete "${this.selectedPlaylist.playlistName}"?`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "Cancel",
    }).then((result) => {
      if (result.isConfirmed) {
        this.playlistsService
          .deletePlaylist(this.selectedPlaylist.playlistID)
          .subscribe({
            next: () => {
              this.showDeleteModal = false;
              this.loadMyPlaylists();
              Swal.fire("Deleted!", "Playlist has been deleted.", "success");
            },
            error: () => {
              Swal.fire("Error", "Could not delete playlist.", "error");
            },
          });
      }
    });
  }

  showPlaylistSongsModal = false;
  playlistSongs: any[] = [];
  selectedPlaylistForView: any = null;

  openPlaylistSongsModal(playlist: any) {
    this.selectedPlaylistForView = playlist;
    this.playlistsService.getSongsInPlaylist(playlist.playlistID).subscribe({
      next: (songs) => {
        this.playlistSongs = songs;
        this.showPlaylistSongsModal = true;
      },
      error: () => {
        this.playlistSongs = [];
        this.showPlaylistSongsModal = true;
      },
    });
  }

  openAddSongsModal(playlist: any) {
    this.selectedPlaylistForSongs = playlist;
    this.songIdsInput = "";
    this.addSongsError = "";
    this.addSongsSuccess = "";
    this.selectedSongIds = new Set();
    this.showAddSongsModal = true;
    this.playlistsService.getAllSongs().subscribe({
      next: (songs) => (this.allSongs = songs),
      error: () => (this.allSongs = []),
    });
  }

  toggleSongSelection(songId: number, event: Event) {
    const checked = (event.target as HTMLInputElement).checked;
    if (checked) {
      this.selectedSongIds.add(songId);
    } else {
      this.selectedSongIds.delete(songId);
    }
  }

  addSongsToPlaylist() {
    const songIds = Array.from(this.selectedSongIds);
    if (!songIds.length) {
      this.addSongsError = "Please select at least one song.";
      return;
    }
    this.playlistsService
      .addSongsToPlaylist(this.selectedPlaylistForSongs.playlistID, songIds)
      .subscribe({
        next: (res) => {
          this.showAddSongsModal = false;
          this.loadMyPlaylists();
          Swal.fire(
            "Added!",
            `Added songs: ${res.added_song_ids.join(", ")}`,
            "success",
          );
        },
        error: (err) => {
          Swal.fire("Error", "Could not add songs to playlist.", "error");
        },
      });
  }
}
