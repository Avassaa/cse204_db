import { Component } from '@angular/core';

@Component({
  selector: 'app-specific-album',
  imports: [],
  templateUrl: './specific-album.component.html',
  styleUrl: './specific-album.component.scss'
})
export class SpecificAlbumComponent {

}
