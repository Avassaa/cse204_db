import { Component } from "@angular/core";
import { Router, RouterModule } from "@angular/router";
import { AuthService } from "../auth.service";
import { CommonModule } from "@angular/common";
import { FormsModule, NgModel } from "@angular/forms";

@Component({
  selector: "app-navbar",
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: "./navbar.component.html",
  styleUrl: "./navbar.component.scss",
})
export class NavbarComponent {
  constructor(
    public auth: AuthService,
    private router: Router,
  ) {}

  searchTerm = "";
  onSearch() {
    this.router.navigate(["/search"], { queryParams: { q: this.searchTerm } });
  }

  logout() {
    this.auth.logout();
    this.router.navigate(["/login"]);
  }
}
