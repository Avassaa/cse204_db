import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { PlaylistsService } from "../playlists.service";

@Component({
  selector: "app-playlist-detail",
  templateUrl: "./playlist-detail.component.html",
  styleUrl: "./playlist-detail.component.scss",
  standalone: true,
  imports: [],
})
export class PlaylistDetailComponent implements OnInit {
  playlistId!: number;
  playlist: any;
  songs: any[] = [];
  allSongs: any[] = [];
  selectedSongIds: Set<number> = new Set();
  showAddSongs = false;
  loading = true;

  constructor(
    private route: ActivatedRoute,
    private playlistsService: PlaylistsService,
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.playlistId = +params["id"];
      this.loadPlaylist();
      this.loadSongs();
    });
  }

  loadPlaylist() {
    // If you have a getPlaylistById method, use it. Otherwise, fetch all and filter.
    // this.playlistsService.getPlaylistById(this.playlistId).subscribe(...)
  }

  loadSongs() {
    this.loading = true;
    this.playlistsService.getSongsInPlaylist(this.playlistId).subscribe({
      next: (songs) => {
        this.songs = songs;
        this.loading = false;
      },
      error: () => {
        this.songs = [];
        this.loading = false;
      },
    });
  }

  openAddSongs() {
    this.showAddSongs = true;
    this.playlistsService.getAllSongs("").subscribe({
      next: (songs) => (this.allSongs = songs),
      error: () => (this.allSongs = []),
    });
  }

  toggleSongSelection(songId: number, event: Event) {
    const checked = (event.target as HTMLInputElement).checked;
    if (checked) {
      this.selectedSongIds.add(songId);
    } else {
      this.selectedSongIds.delete(songId);
    }
  }

  addSongsToPlaylist() {
    const songIds = Array.from(this.selectedSongIds);
    if (!songIds.length) return;
    this.playlistsService
      .addSongsToPlaylist(this.playlistId, songIds)
      .subscribe({
        next: () => {
          this.showAddSongs = false;
          this.loadSongs();
        },
      });
  }
}
